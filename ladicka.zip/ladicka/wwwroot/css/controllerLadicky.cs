﻿namespace ladicka.wwwroot.css
{
    public class controllerLadicky
    {
        .meter {
    width: 500px;
    height: 10px;
    background: #394867;
    position: relative;
    margin: 30px auto;
    }

#showyThing  {
    width: 4px;
    height: 30px;
    background: lime;
    position: absolute;
    left: 50%;
    top: -10px;

    transition: left 0.1s;
}
    }

}
